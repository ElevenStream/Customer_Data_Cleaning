# Executive Summary

This project simulates the role of a data analyst at a U.S.-based subscription business in 2025. Our objective is to clean, analyze, and prepare customer data for business insights and executive reporting.

The data was generated using Faker to simulate realistic challenges: missing values, duplicates, and formatting issues.

**Business Questions Addressed:**
- What is the customer distribution by region?
- How clean is our customer data?
- What can we predict or optimize with better data?

**Tools Used:** Python, SQLite, Google Colab, Looker Studio  
**Outcome:** Clean datasets, SQL analysis, visualizations, and Looker-ready files.