# Stakeholder Questions

Our stakeholders need answers to guide decision-making.

1. Which region has the most customers?
2. What percentage of data is incomplete or duplicated?
3. What would happen if we increased customer retention by 10%?
4. Are there trends in signup dates we can leverage?

We will use SQL queries, data cleaning, and visualizations to answer these questions.