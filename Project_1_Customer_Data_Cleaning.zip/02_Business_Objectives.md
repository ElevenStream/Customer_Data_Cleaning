# Business Objectives & KPIs

Our fictional company offers a subscription service. The business team wants to understand customer behaviors and improve retention.

## Key Objectives:
- Clean customer records to ensure data integrity.
- Analyze behavior by region and signup date.
- Prepare Looker Studio-ready files for dashboards.

## Key Performance Indicators (KPIs):
- % of missing data (before/after cleaning)
- % of duplicates removed
- Customer growth over time
- Retention trends (cohort-based)
- Top performing regions