# SQL Queries for Business Analysis

We used SQLite to query cleaned customer data. These queries help stakeholders answer real-world business questions.

## Key Queries:
- Total customers by region
- Average customer lifespan
- Monthly signup trends
- Top 5 most active regions

All SQL code is written directly inside Colab using `sqlite3`.