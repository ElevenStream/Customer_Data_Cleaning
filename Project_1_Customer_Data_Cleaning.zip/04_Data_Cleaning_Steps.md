# Data Cleaning Steps

Our raw dataset had missing fields, inconsistent formats, and duplicate records. These are common issues in customer data pipelines.

## Steps Taken:
- Dropped duplicate entries.
- Formatted date columns uniformly (YYYY-MM-DD).
- Replaced missing regions with 'Unknown'.
- Removed rows with critical missing info (e.g., names or emails).

> **Why this matters**: Bad data leads to bad decisions. Cleaning ensures reliable KPIs and forecasting.